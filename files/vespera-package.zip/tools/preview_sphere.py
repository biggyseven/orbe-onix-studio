#!/usr/bin/env python3
"""CPU preview of VESPERA (orthographic) that mirrors the intended GLSL shading.
usage: preview_sphere.py <tex_dir> <out.png> [yaw_deg] [cloud_yaw_deg] [size]"""
import sys, numpy as np, cv2
from PIL import Image

D = sys.argv[1]; OUT = sys.argv[2]
YAW = np.radians(float(sys.argv[3])) if len(sys.argv) > 3 else 0.0
CYAW = np.radians(float(sys.argv[4])) if len(sys.argv) > 4 else 0.35
S = int(sys.argv[5]) if len(sys.argv) > 5 else 1000
TILT = np.radians(14.0)

def load(n):
    return np.asarray(Image.open(f"{D}/{n}.webp").convert("RGB"), np.float32) / 255.0
col_t, nor_t, orm_t, cld_t = load("color"), load("normal"), load("orm"), load("clouds")[..., 0]
TH, TW = col_t.shape[:2]
srgb2lin = lambda c: np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)
col_t = srgb2lin(col_t)

def samp(tex, u, v, interp=cv2.INTER_LINEAR):
    mx = (u * TW - 0.5).astype(np.float32); my = (v * TH - 0.5).astype(np.float32)
    return cv2.remap(tex, mx, my, interp, borderMode=cv2.BORDER_WRAP)

def smooth(a, b, x):
    k = np.clip((x - a) / (b - a), 0, 1); return k * k * (3 - 2 * k)

def rotY(a):
    c, s = np.cos(a), np.sin(a); return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]], np.float32)
def rotZ(a):
    c, s = np.cos(a), np.sin(a); return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]], np.float32)

# view -> local rotation (planet tilted then spun)
M_planet = rotZ(TILT) @ rotY(YAW)         # local -> view
M_inv = M_planet.T
M_cloud = rotZ(TILT) @ rotY(YAW + CYAW)

L_view = np.array([-0.85, 0.30, 0.45], np.float32); L_view /= np.linalg.norm(L_view)

ext = 1.13
ys, xs = np.mgrid[0:S, 0:S].astype(np.float32)
X = (xs / (S - 1) * 2 - 1) * ext; Y = -(ys / (S - 1) * 2 - 1) * ext
R2 = X * X + Y * Y; R = np.sqrt(R2)

def to_lonlat(p):
    lon = np.arctan2(p[..., 2], p[..., 0]); lat = np.arcsin(np.clip(p[..., 1], -1, 1))
    return (lon / (2 * np.pi) + 0.5) % 1.0, 0.5 - lat / np.pi

def mv(M, v):  # apply 3x3 to (...,3)
    return v @ M.T

out = np.zeros((S, S, 3), np.float32); alpha = np.zeros((S, S), np.float32)

# ------------------------------------------------------------ surface
inside = R < 1.0
Zs = np.sqrt(np.clip(1 - R2, 0, 1))
Nv = np.stack([X, Y, Zs], -1)
Nl = mv(M_inv, Nv)                                   # local normal (sphere)
u, v = to_lonlat(Nl)
lonr = (u - 0.5) * 2 * np.pi; latr = (0.5 - v) * np.pi
east = np.stack([-np.sin(lonr), np.zeros_like(lonr), np.cos(lonr)], -1)
north = np.stack([-np.sin(latr) * np.cos(lonr), np.cos(latr), -np.sin(latr) * np.sin(lonr)], -1)
alb = samp(col_t, u, v); nm = samp(nor_t, u, v) * 2 - 1; orm = samp(orm_t, u, v)
n_loc = nm[..., 0:1] * east + nm[..., 1:2] * north + nm[..., 2:3] * Nl
n_loc /= np.linalg.norm(n_loc, axis=-1, keepdims=True)
Ll = M_inv @ L_view; Vl = M_inv @ np.array([0, 0, 1], np.float32)

# cloud shadow: sample cloud map displaced away from the sun, in cloud-local frame
Lt = Ll - Nl * np.sum(Ll * Nl, -1, keepdims=True)
pc = Nl - 0.020 * Lt / np.maximum(np.linalg.norm(Lt, axis=-1, keepdims=True), 1e-3) * np.sqrt(np.sum(Lt * Lt, -1, keepdims=True))
pc /= np.linalg.norm(pc, axis=-1, keepdims=True)
pc_cloud = mv(M_cloud.T @ M_planet, pc)               # planet-local -> cloud-local
uc, vc = to_lonlat(pc_cloud)
cs = cv2.GaussianBlur(cld_t, (0, 0), 3.0)
shadow = samp(cs, uc, vc)
alb_s = alb * (1 - 0.62 * shadow[..., None])

ndl = np.sum(n_loc * Ll, -1); ndl_s = np.sum(Nl * Ll, -1)
diff = np.clip(ndl, 0, 1)
terminator = smooth(-0.02, 0.18, ndl_s)              # keeps geometry terminator from normal-map noise
Hh = Ll + Vl; Hh /= np.linalg.norm(Hh, axis=-1, keepdims=True)
rough = np.clip(orm[..., 1], 0.25, 1.0); a2 = (rough ** 2) ** 2
ndh = np.clip(np.sum(n_loc * Hh, -1), 0, 1)
dd = ndh * ndh * (a2 - 1) + 1; ggx = a2 / (np.pi * dd * dd)
spec = ggx * 0.04 * (1 - rough) ** 1.5 * np.clip(ndl, 0, 1) * 1.2
SUN = 2.0
amb = np.array([0.020, 0.024, 0.060], np.float32)
sunc = np.array([1.0, 0.95, 0.92], np.float32)
cav = orm[..., 0:1]
surf = alb_s * (diff * terminator)[..., None] * sunc * SUN * (0.55 + 0.9 * cav) \
     + spec[..., None] * SUN * sunc * terminator[..., None] \
     + alb * amb * (0.4 + 0.8 * cav)
# faint rim of lavender backscatter on the lit limb
fres = (1 - np.clip(Nv[..., 2], 0, 1)) ** 3
surf += fres[..., None] * np.array([0.10, 0.09, 0.22], np.float32) * smooth(-0.1, 0.5, ndl_s)[..., None] * 0.6
out[inside] = surf[inside]; alpha[inside] = 1

# ------------------------------------------------------------ clouds
RC = 1.014
inc = R < RC
Zc = np.sqrt(np.clip(RC * RC - R2, 0, None))
Pc = np.stack([X, Y, Zc], -1) / RC
Pcl = mv(M_cloud.T, Pc)
uC, vC = to_lonlat(Pcl)
d0 = samp(cld_t, uC, vC)
lonc = (uC - 0.5) * 2 * np.pi; latc = (0.5 - vC) * np.pi
Lc = M_cloud.T @ L_view
Ec = np.stack([-np.sin(lonc), np.zeros_like(lonc), np.cos(lonc)], -1)
Nn = np.stack([-np.sin(latc) * np.cos(lonc), np.cos(latc), -np.sin(latc) * np.sin(lonc)], -1)
du = np.sum(Ec * Lc, -1) / (2 * np.pi * np.maximum(np.cos(latc), 0.2)) * 0.010
dv = -np.sum(Nn * Lc, -1) / np.pi * 0.010
d1 = samp(cld_t, uC + du, vC + dv)
d2 = samp(cld_t, uC + 2.2 * du, vC + 2.2 * dv)
selfshadow = np.clip((np.maximum(d1, d2) - d0) * 3.2, 0, 1)
ndlc = np.sum(Pcl * Lc, -1)
lit = smooth(-0.12, 0.45, ndlc)
sunCol = (1 - smooth(0.0, 0.5, ndlc))[..., None] * np.array([1.0, 0.70, 0.92], np.float32) \
       + smooth(0.0, 0.5, ndlc)[..., None] * np.array([1.0, 0.985, 0.97], np.float32)
body = d0 ** 1.25
albc = np.array([0.93, 0.93, 0.98], np.float32) * (1 - 0.16 * body[..., None]) \
     + np.array([0.80, 0.74, 1.0], np.float32) * 0.16 * body[..., None]   # lavender tint in dense cores
shade = (1 - 0.60 * selfshadow) * (1 - 0.38 * body)
cld = albc * sunCol * (lit * shade * SUN * 0.50)[..., None] + albc * amb * 2.2
# silver edge light where thin cloud meets sun
edge = (1 - d0) ** 2 * d0 * 4.0 * lit
cld += edge[..., None] * np.array([0.75, 0.78, 1.0], np.float32) * 0.5
a_c = np.clip(d0 ** 1.0 * 0.92, 0, 1) * inc
out = out * (1 - a_c[..., None]) + cld * a_c[..., None]
alpha = np.maximum(alpha, a_c)

# ------------------------------------------------------------ atmosphere (analytic, mirrors GLSL)
Rp, Hs = 1.0, 0.024
b = R
mu = np.sqrt(np.clip(1 - (b / Rp) ** 2, 0, 1))
graz = np.sqrt(2 * np.pi * Hs * Rp)
col_in = np.minimum(Hs / np.maximum(mu, 0.02), graz)
col_out = np.sqrt(2 * np.pi * np.maximum(b, 1e-3) * Hs) * np.exp(-(b - Rp) / Hs)
colden = np.where(b < Rp, col_in, col_out)
opac = 1 - np.exp(-3.4 * colden)
opac *= (R < 1.12)
nz = np.where(b < Rp, Zs * 0.45, 0.0)
ns = np.stack([X, Y, nz], -1); ns /= np.maximum(np.linalg.norm(ns, axis=-1, keepdims=True), 1e-4)
s = np.sum(ns * L_view, -1)
day = smooth(-0.18, 0.55, s)
twi = np.exp(-(s / 0.20) ** 2)
cos_t = -L_view[2]
g = 0.45
hg = (1 - g * g) / (4 * np.pi * (1 + g * g - 2 * g * cos_t) ** 1.5)
phase = 0.6 + 0.4 * (0.75 * (1 + cos_t * cos_t)) + 1.1 * hg
dayc = np.array([0.42, 0.52, 1.00], np.float32); lavc = np.array([0.72, 0.58, 1.0], np.float32)
twic = np.array([1.00, 0.50, 0.80], np.float32)
acol = (dayc * (1 - 0.35 * day[..., None]) + lavc * 0.35 * day[..., None]) * day[..., None] \
     + twic * (twi * 0.55)[..., None]
a_atm = np.clip(opac * (0.04 + 0.96 * np.clip(day + 0.45 * twi, 0, 1)) * phase * 0.85, 0, 1)
out = out + acol * a_atm[..., None] * 1.15
alpha = np.maximum(alpha, a_atm)

# ------------------------------------------------------------ tonemap (ACES fit) + sRGB
def aces(x):
    a, b_, c, d, e = 2.51, 0.03, 2.43, 0.59, 0.14
    return np.clip((x * (a * x + b_)) / (x * (c * x + d) + e), 0, 1)
EXPO = 1.0
img = aces(out * EXPO)
img = np.where(img <= 0.0031308, img * 12.92, 1.055 * np.power(np.maximum(img, 1e-6), 1 / 2.4) - 0.055)
bg = np.array([0.043, 0.043, 0.059], np.float32)    # #0b0b0f site-like backdrop
comp = img * alpha[..., None] + bg * (1 - alpha[..., None])
Image.fromarray((np.clip(comp, 0, 1) * 255).astype(np.uint8)).save(OUT)
# transparent version for poster
rgba = np.dstack([np.clip(img, 0, 1), alpha]); np.save(OUT + ".rgba.npy", (rgba * 255).astype(np.uint8))
print("ok", OUT)
