import sys, subprocess, time
from playwright.sync_api import sync_playwright
out=sys.argv[1]; qs=sys.argv[2] if len(sys.argv)>2 else ""
srv=subprocess.Popen(["python3","-m","http.server","8765","--bind","127.0.0.1"],cwd="/home/claude/vespera",stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); time.sleep(1)
try:
  with sync_playwright() as p:
    b=p.chromium.launch(args=["--use-gl=swiftshader","--enable-unsafe-swiftshader","--ignore-gpu-blocklist","--use-angle=swiftshader"])
    pg=b.new_page(viewport={"width":1000,"height":1000}); logs=[]
    pg.on("console",lambda m:logs.append(m.text)); pg.on("pageerror",lambda e:logs.append("PAGEERR "+str(e)))
    pg.goto("http://127.0.0.1:8765/scripts/harness.html?"+qs); pg.wait_for_function("window.__done===true",timeout=120000)
    print("shader errors:",pg.evaluate("window.__errs")); print("console:",logs[:5])
    pg.screenshot(path=out, omit_background=('bg=none' in qs)); b.close()
finally: srv.terminate()
