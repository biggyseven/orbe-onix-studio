#!/usr/bin/env python3
"""
VESPERA texture generator (offline, run once).

Everything is sampled as 3D noise on the unit sphere -> no seam, no pole pinching.
Outputs (assets/vespera/<size>/):
  color.webp   albedo (sRGB)
  normal.webp  tangent-space normal map
  orm.webp     R = cavity/AO, G = roughness, B = height   (Three: aoMap + roughnessMap share it)
  clouds.webp  grayscale cloud density (R=G=B)

usage: python make_vespera_textures.py [width] [out_dir]
"""
import sys, os, time
import numpy as np
from PIL import Image
from scipy.ndimage import gaussian_filter, zoom

W = int(sys.argv[1]) if len(sys.argv) > 1 else 4096
OUT = sys.argv[2] if len(sys.argv) > 2 else "out"
H = W // 2
rng = np.random.default_rng(7)  # fixed seed -> reproducible planet

# ---------------------------------------------------------------- sphere grid
lon = (np.arange(W, dtype=np.float32) + 0.5) / W * 2 * np.pi - np.pi
lat = np.pi / 2 - (np.arange(H, dtype=np.float32) + 0.5) / H * np.pi
LON, LAT = np.meshgrid(lon, lat)
cl = np.cos(LAT)
PX = (cl * np.cos(LON)).astype(np.float32)
PY = np.sin(LAT).astype(np.float32)
PZ = (cl * np.sin(LON)).astype(np.float32)
del LON

# ---------------------------------------------------------------- 3D value noise
TABLE_N = 256
_tab = rng.random((TABLE_N,), dtype=np.float32) * 2 - 1
_perm = rng.permutation(TABLE_N).astype(np.int32)


def _h(ix, iy, iz):
    return _tab[_perm[(_perm[(_perm[ix & 255] + iy) & 255] + iz) & 255]]


def noise3(x, y, z):
    """smooth 3D value noise in [-1,1] (quintic fade)."""
    x0 = np.floor(x); y0 = np.floor(y); z0 = np.floor(z)
    fx = x - x0; fy = y - y0; fz = z - z0
    ix = x0.astype(np.int32); iy = y0.astype(np.int32); iz = z0.astype(np.int32)
    u = fx * fx * fx * (fx * (fx * 6 - 15) + 10)
    v = fy * fy * fy * (fy * (fy * 6 - 15) + 10)
    w = fz * fz * fz * (fz * (fz * 6 - 15) + 10)
    c000 = _h(ix, iy, iz);         c100 = _h(ix + 1, iy, iz)
    c010 = _h(ix, iy + 1, iz);     c110 = _h(ix + 1, iy + 1, iz)
    c001 = _h(ix, iy, iz + 1);     c101 = _h(ix + 1, iy, iz + 1)
    c011 = _h(ix, iy + 1, iz + 1); c111 = _h(ix + 1, iy + 1, iz + 1)
    a = c000 + (c100 - c000) * u; b = c010 + (c110 - c010) * u
    c = c001 + (c101 - c001) * u; d = c011 + (c111 - c011) * u
    e = a + (b - a) * v; f = c + (d - c) * v
    return e + (f - e) * w


# rotate each octave so lattice axes never line up (kills grid artifacts)
_R = np.array([[0.8, -0.6, 0.0], [0.6, 0.8, 0.0], [0.0, 0.0, 1.0]], np.float32)
_R2 = np.array([[1, 0, 0], [0, 0.936, -0.352], [0, 0.352, 0.936]], np.float32)
ROT = (_R @ _R2).astype(np.float32)


def rot(x, y, z):
    return (ROT[0, 0] * x + ROT[0, 1] * y + ROT[0, 2] * z,
            ROT[1, 0] * x + ROT[1, 1] * y + ROT[1, 2] * z,
            ROT[2, 0] * x + ROT[2, 1] * y + ROT[2, 2] * z)


def fbm(x, y, z, octaves, lacunarity=2.03, gain=0.5, ridged=False, seed_off=0.0):
    tot = np.zeros_like(x); amp = 1.0; norm = 0.0
    ox, oy, oz = seed_off, seed_off * 1.3, seed_off * 0.7
    for _ in range(octaves):
        n = noise3(x + ox, y + oy, z + oz)
        if ridged:
            n = 1.0 - np.abs(n) * 1.6
            n = np.clip(n, 0, 1) ** 2
            n = n * 2 - 1
        tot += n * amp; norm += amp
        x, y, z = rot(x * lacunarity, y * lacunarity, z * lacunarity)
        amp *= gain
    return tot / norm


def t(msg, t0):
    print(f"  {msg:<28s} {time.time()-t0:5.1f}s", flush=True)


def smooth(a, b, x):
    k = np.clip((x - a) / (b - a), 0, 1)
    return k * k * (3 - 2 * k)


def mixc(c0, c1, k):
    c0 = c0 if c0.ndim == 3 else c0[None, None, :]
    c1 = c1 if c1.ndim == 3 else c1[None, None, :]
    return c0 * (1 - k[..., None]) + c1 * k[..., None]


def hexc(h):
    h = h.lstrip('#')
    return np.array([int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)], np.float32)


# ================================================================= HEIGHT
print(f"VESPERA {W}x{H}")
T0 = time.time()

# domain warp -> geological flow instead of "blobby" noise
wx = fbm(PX * 1.3, PY * 1.3, PZ * 1.3, 4, seed_off=11.0)
wy = fbm(PX * 1.3, PY * 1.3, PZ * 1.3, 4, seed_off=23.0)
wz = fbm(PX * 1.3, PY * 1.3, PZ * 1.3, 4, seed_off=37.0)
WX = PX + 0.20 * wx; WY = PY + 0.20 * wy; WZ = PZ + 0.20 * wz
t("domain warp", T0)

# continental scale: highlands vs basins
cont = fbm(WX * 2.1, WY * 2.1, WZ * 2.1, 7, seed_off=3.0)
cont = cont * 0.5 + 0.5
highland = smooth(0.38, 0.66, cont)           # 0 = basin, 1 = highland
t("continents", T0)

# mountain chains: ridged, only on highlands, aligned by warp
ridges = fbm(WX * 3.2, WY * 3.2, WZ * 3.2, 7, ridged=True, seed_off=51.0)
ridges = np.clip(ridges * 0.5 + 0.5, 0, 1)
mount = ridges * (0.25 + 0.75 * highland)
t("ridges", T0)

# plateaus / terraces (mineral layering)
terr = fbm(WX * 2.1, WY * 2.1, WZ * 2.1, 5, seed_off=71.0) * 0.5 + 0.5
terr = np.floor(terr * 7.0) / 7.0 + smooth(0.0, 1.0, (terr * 7.0) % 1.0) / 7.0 * 0.55

# fractures / rifts: thin valleys along warped lines
f1 = np.abs(fbm(WX * 2.4, WY * 2.4, WZ * 2.4, 3, seed_off=91.0))
f2 = np.abs(fbm(WX * 5.5, WY * 5.5, WZ * 5.5, 3, seed_off=97.0))
rpatch = smooth(0.52, 0.72, fbm(PX * 3.0, PY * 3.0, PZ * 3.0, 3, seed_off=81.0) * 0.5 + 0.5)
rift = (1 - smooth(0.0, 0.020, f1)) * smooth(0.48, 0.60, cont) * rpatch \
     + 0.5 * (1 - smooth(0.0, 0.014, f2)) * highland * rpatch
rift = np.clip(rift, 0, 1)
t("terraces + fractures", T0)

# fine surface grain
grain = fbm(PX * 38, PY * 38, PZ * 38, 5, gain=0.55, seed_off=5.0)
detail = fbm(PX * 11, PY * 11, PZ * 11, 5, seed_off=15.0)
t("grain", T0)

height = (0.42 * highland + 0.34 * mount * highland + 0.12 * terr * highland
          + 0.07 * detail + 0.028 * grain - 0.10 * rift + 0.08)

# impact basins & craters (analytic, power-law sizes)
NC = 170 if W >= 2048 else 90
cx = rng.normal(size=(NC, 3)); cx /= np.linalg.norm(cx, axis=1, keepdims=True)
rad = 0.018 + 0.20 * rng.power(0.22, NC) ** 3.2 * 0.62 + 0.020 * rng.random(NC)
rad = np.sort(rad)[::-1]
crater_mask = np.zeros_like(height)
for i in range(NC):
    cd = PX * cx[i, 0] + PY * cx[i, 1] + PZ * cx[i, 2]
    ang = np.arccos(np.clip(cd, -1, 1))
    r = ang / rad[i]
    m = r < 1.6
    if not m.any():
        continue
    rr = r[m]
    bowl = -(1 - smooth(0.0, 1.0, rr)) * 1.0           # depression
    rim = np.exp(-((rr - 1.02) / 0.12) ** 2) * 0.55     # raised rim
    floor_ = np.exp(-(rr / 0.35) ** 2) * 0.12           # central uplift
    prof = (bowl + rim * 0.8 + floor_) * (0.03 + 0.28 * rad[i] ** 0.8)
    height[m] += prof
    crater_mask[m] = np.maximum(crater_mask[m], 1 - smooth(0.0, 1.25, rr))
t("craters", T0)

hmin, hmax = np.percentile(height, [0.3, 99.7])
height = np.clip((height - hmin) / (hmax - hmin), 0, 1).astype(np.float32)

# ================================================================= COLOR
# palette: graphite / night blue / indigo base, lavender-violet provinces, ivory highs
GRAPH = hexc('252430'); NIGHT = hexc('1a1d3a'); INDIGO = hexc('2c2d62')
VIOLET = hexc('5d3f9e'); LAV = hexc('9684cf'); LAV2 = hexc('b8a8ea')
IVORY = hexc('d9d0cf'); MAUVE = hexc('7a5aa8')

prov = fbm(WX * 2.6, WY * 2.6, WZ * 2.6, 6, seed_off=111.0) * 0.5 + 0.5   # mineral provinces
prov2 = fbm(WX * 3.3, WY * 3.3, WZ * 3.3, 5, seed_off=133.0) * 0.5 + 0.5
strata = fbm(PX * 14 + 2 * wx, PY * 40 + 2 * wy, PZ * 14 + 2 * wz, 4, seed_off=151.0) * 0.5 + 0.5

col = mixc(GRAPH, NIGHT, smooth(0.45, 0.85, prov2) * 0.7)
rock = fbm(PX * 22, PY * 22, PZ * 22, 6, gain=0.58, ridged=True, seed_off=181.0) * 0.5 + 0.5
col = col * (0.65 + 0.70 * rock)[..., None]
col = mixc(col, INDIGO, smooth(0.40, 0.85, 1 - height) * 0.35)
plains = smooth(0.55, 0.80, 1 - cont) * smooth(0.35, 0.65, prov2)
col = mixc(col, hexc('14141c'), plains * 0.7)               # deep basins -> indigo
col = mixc(col, VIOLET, smooth(0.40, 0.66, prov) * smooth(0.10, 0.45, height) * 0.95)
col = mixc(col, MAUVE, smooth(0.62, 0.85, prov2) * smooth(0.3, 0.7, height) * 0.7)
col = mixc(col, LAV, smooth(0.52, 0.78, prov) * smooth(0.30, 0.65, height) * 0.92)
col = mixc(col, LAV2, smooth(0.68, 0.90, prov) * smooth(0.50, 0.85, height) * 0.75)
# subtle strata banding in mid elevations
col *= (0.90 + 0.20 * strata)[..., None] ** 1.0
# ivory deposits: summits + salt-flat-like patches in some basins
salt = fbm(WX * 2.6, WY * 2.6, WZ * 2.6, 5, seed_off=171.0) * 0.5 + 0.5
ivory_k = smooth(0.78, 0.95, height) * 0.8 + smooth(0.70, 0.82, salt) * smooth(0.0, 0.5, 1 - highland) * 0.7
ivory_k = np.clip(ivory_k * (0.55 + 0.45 * smooth(0.3, 0.7, grain * 0.5 + 0.5)), 0, 1)
col = mixc(col, IVORY, ivory_k)

# cavity / curvature from height (dark in creases, light on crests)
blur_s = gaussian_filter(height, (W / 700, W / 700), mode=('nearest', 'wrap'))
blur_l = gaussian_filter(height, (W / 150, W / 150), mode=('nearest', 'wrap'))
cav = np.clip(0.5 + (height - blur_s) * 9.0 + (height - blur_l) * 2.2, 0, 1)
pole = smooth(0.10, 0.30, cl)
cav = 0.5 + (cav - 0.5) * pole
col *= (0.70 + 0.52 * cav)[..., None]
col *= (1 - 0.22 * rift)[..., None]                          # rifts darker
col = np.clip(col, 0, 1)
t("colour", T0)

# ================================================================= NORMAL
BUMP = 3.4 * (W / 4096.0 + 0.5)       # strength tuned per resolution
hx = np.roll(height, -1, 1) - np.roll(height, 1, 1)
hy = np.vstack([height[1:2] - height[0:1], height[2:] - height[:-2], height[-1:] - height[-2:-1]])
cosl = np.maximum(cl, 0.12)
nx = -hx * BUMP * (W / 512.0) / cosl
ny = hy * BUMP * (W / 512.0)       # v axis points down in the image -> +Y in tangent space
nz = np.ones_like(nx)
ln = np.sqrt(nx * nx + ny * ny + nz * nz)
pf = smooth(0.08, 0.28, cl); nx *= pf; ny *= pf
ln = np.sqrt(nx * nx + ny * ny + nz * nz)
normal = np.stack([nx / ln, ny / ln, nz / ln], -1) * 0.5 + 0.5
t("normal", T0)

# ================================================================= ORM
rough = 0.86 - 0.18 * smooth(0.3, 0.9, ivory_k) - 0.10 * (1 - highland) + 0.08 * grain
rough = np.clip(rough, 0.3, 1.0)
orm = np.stack([cav, rough, height], -1)

for _n in ('wx','wy','wz','WX','WY','WZ','ridges','mount','terr','f1','f2','detail','rpatch','prov','prov2','strata','rock','salt','plains','blur_s','blur_l','hx','hy','nx','ny','nz','ln','rift','crater_mask'):
    globals().pop(_n, None)
import gc; gc.collect()
# ================================================================= CLOUDS
# zonal flow: stretch the field along latitude bands + two warp scales -> filaments & swirls
cwx = fbm(PX * 2.0, PY * 2.0, PZ * 2.0, 4, seed_off=201.0)
cwy = fbm(PX * 2.0, PY * 2.0, PZ * 2.0, 4, seed_off=211.0)
cwz = fbm(PX * 2.0, PY * 2.0, PZ * 2.0, 4, seed_off=221.0)
CX = PX + 0.30 * cwx; CY = PY + 0.10 * cwy; CZ = PZ + 0.30 * cwz
bands = np.sin(LAT * 5.0 + 2.2 * fbm(PX * 1.5, PY * 1.5, PZ * 1.5, 3, seed_off=231.0)) * 0.5 + 0.5
body = fbm(CX * 3.4, CY * 8.0, CZ * 3.4, 8, gain=0.55, seed_off=241.0) * 0.5 + 0.5
cover = fbm(PX * 1.1, PY * 1.1, PZ * 1.1, 4, seed_off=251.0) * 0.5 + 0.5
dens = body * (0.62 + 0.50 * bands) + (cover - 0.5) * 0.46 + 0.085
dens = smooth(0.47, 0.85, dens)
# thin cirrus filaments
fil = fbm(CX * 4.2, CY * 9.0, CZ * 4.2, 6, ridged=True, seed_off=261.0) * 0.5 + 0.5
fil = gaussian_filter(fil, (0.5, W / 700), mode=('nearest', 'wrap'))
fil = smooth(0.58, 0.88, fil) * smooth(0.35, 0.70, cover) * 0.42
# dense cores for volumetric depth
core = smooth(0.62, 0.95, body * (0.7 + 0.5 * bands)) * dens
mott = fbm(CX * 9, CY * 14, CZ * 9, 5, seed_off=271.0) * 0.5 + 0.5
clouds = dens * (0.50 + 0.28 * mott) + core * 0.22 + fil * (1 - dens * 0.5)
clouds = 1 - np.exp(-clouds * 1.55)
clouds = np.clip(clouds, 0, 1)
print(f"  cloud coverage (>0.35): {(clouds > 0.35).mean()*100:.0f}%  mean {clouds.mean():.2f}")
t("clouds", T0)


# ================================================================= WRITE
def to8(a):
    return (np.clip(a, 0, 1) * 255 + 0.5).astype(np.uint8)


os.makedirs(OUT, exist_ok=True)
Image.fromarray(to8(col)).save(f"{OUT}/color.webp", quality=90, method=6)
Image.fromarray(to8(normal)).save(f"{OUT}/normal.webp", quality=92, method=6)
Image.fromarray(to8(orm)).save(f"{OUT}/orm.webp", quality=88, method=6)
c8 = to8(clouds)
Image.fromarray(np.stack([c8, c8, c8], -1)).save(f"{OUT}/clouds.webp", quality=88, method=6)
# float height for the preview renderer
np.save(f"{OUT}/_height.npy", height.astype(np.float16))
for f in ("color", "normal", "orm", "clouds"):
    print(f"  {f}.webp  {os.path.getsize(f'{OUT}/{f}.webp')/1024:7.0f} KB")
t("done", T0)
