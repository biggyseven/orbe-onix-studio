#!/usr/bin/env python3
"""Lune de VESPERA : gris froid teinté lavande, mers sombres, cratères (loi de puissance).
usage: python make_moon_textures.py [width] [out_dir]   -> color.webp, normal.webp"""
import sys, os, re
W = int(sys.argv[1]) if len(sys.argv) > 1 else 2048
OUT = sys.argv[2] if len(sys.argv) > 2 else "out_moon"
# réutilise la grille sphérique et le bruit 3D du script de la planète (même dossier)
src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "make_vespera_textures.py")).read()
head = src.split("# ================================================================= HEIGHT")[0]
sys.argv = [sys.argv[0], str(W), OUT]
exec(head)                                            # définit PX,PY,PZ,fbm,smooth,mixc,hexc,rng,W,H,cl...
rng = np.random.default_rng(21)

# relief : basses terres douces + grain, puis cratères
base = fbm(PX * 1.6, PY * 1.6, PZ * 1.6, 6, seed_off=301.0) * 0.5 + 0.5
mare = smooth(0.50, 0.66, fbm(PX * 1.1, PY * 1.1, PZ * 1.1, 5, seed_off=311.0) * 0.5 + 0.5)   # mers sombres
grain = fbm(PX * 30, PY * 30, PZ * 30, 5, gain=0.55, seed_off=321.0)
height = 0.55 * base * (1 - 0.55 * mare) + 0.03 * grain
fresh = np.zeros_like(height)
NC = 420 if W >= 2048 else 220
cx = rng.normal(size=(NC, 3)); cx /= np.linalg.norm(cx, axis=1, keepdims=True)
rad = np.sort(0.012 + 0.16 * rng.power(0.25, NC) ** 3.4)[::-1]
for i in range(NC):
    cd = PX * cx[i, 0] + PY * cx[i, 1] + PZ * cx[i, 2]
    r = np.arccos(np.clip(cd, -1, 1)) / rad[i]
    m = r < 1.7
    if not m.any(): continue
    rr = r[m]
    prof = (-(1 - smooth(0.0, 1.0, rr)) + 0.7 * np.exp(-((rr - 1.03) / 0.13) ** 2)
            + 0.14 * np.exp(-(rr / 0.3) ** 2)) * (0.04 + 0.30 * rad[i] ** 0.8)
    height[m] += prof
    fresh[m] = np.maximum(fresh[m], np.exp(-((rr - 1.10) / 0.45) ** 2) * (0.35 + 0.65 * rng.random()))
height = (height - np.percentile(height, 0.3)) / (np.percentile(height, 99.7) - np.percentile(height, 0.3))
height = np.clip(height, 0, 1).astype(np.float32)

# couleur : gris froid lavande ; mers plus sombres et bleutées ; cratères récents plus clairs
HIGH = hexc('a29fae'); LOW = hexc('6d6a7c'); MARE = hexc('3f3e52'); BRIGHT = hexc('cfcbd8')
col = mixc(LOW, HIGH, smooth(0.25, 0.85, height))
col = mixc(col, MARE, mare * 0.75)
col = mixc(col, BRIGHT, np.clip(fresh * 0.75, 0, 1))
col *= (0.82 + 0.36 * (fbm(PX * 18, PY * 18, PZ * 18, 5, seed_off=331.0) * 0.5 + 0.5))[..., None]
col = np.clip(col, 0, 1)

# normale (atténuée aux pôles)
BUMP = 4.2 * (W / 4096.0 + 0.5)
hx = np.roll(height, -1, 1) - np.roll(height, 1, 1)
hy = np.vstack([height[1:2] - height[0:1], height[2:] - height[:-2], height[-1:] - height[-2:-1]])
pf = smooth(0.08, 0.28, cl)
nx = -hx * BUMP * (W / 512.0) / np.maximum(cl, 0.12) * pf
ny = hy * BUMP * (W / 512.0) * pf
nz = np.ones_like(nx); ln = np.sqrt(nx * nx + ny * ny + nz * nz)
normal = np.stack([nx / ln, ny / ln, nz / ln], -1) * 0.5 + 0.5

to8 = lambda a: (np.clip(a, 0, 1) * 255 + 0.5).astype(np.uint8)
os.makedirs(OUT, exist_ok=True)
Image.fromarray(to8(col)).save(f"{OUT}/color.webp", quality=90, method=6)
Image.fromarray(to8(normal)).save(f"{OUT}/normal.webp", quality=92, method=6)
for f in ("color", "normal"): print(f, os.path.getsize(f"{OUT}/{f}.webp") // 1024, "KB")
